package org.mjdev.desktop.components.controlcenter.pages.bluetooth

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import org.mjdev.desktop.components.controlcenter.base.ControlCenterPage
import org.mjdev.desktop.components.controlcenter.settings.SettingsDeviceSection
import org.mjdev.desktop.components.controlcenter.settings.SettingsInfoRow
import org.mjdev.desktop.components.controlcenter.settings.SettingsPageColumn
import org.mjdev.desktop.components.controlcenter.settings.SettingsSection
import org.mjdev.desktop.context.IDesktopContext
import org.mjdev.desktop.data.BthDevice
import org.mjdev.desktop.data.NetDevice
import org.mjdev.desktop.extensions.Compose.preview
import org.mjdev.desktop.extensions.LaunchedEffect.flowBlock
import org.mjdev.desktop.icons.network.Bluetooth

/** Static labels used by [BluetoothSettingsPage]. */
private object BluetoothLabels {
    const val ADAPTERS = "Bluetooth adapters"
    const val NEARBY = "Known devices"
    const val NONE = "No devices found"
}

/** Refresh period of the lists in milliseconds. */
private const val REFRESH_MS = 1000L

/** Control center page listing bluetooth adapters and known devices; hidden without an adapter. */
@Suppress("FunctionName")
fun BluetoothSettingsPage(context: IDesktopContext) = ControlCenterPage(
    context = context,
    icon = Bluetooth,
    name = "Bluetooth",
    condition = {
        connectionManager.isBthAdapterAvailable
    },
) {
    val adapters: Map<String, NetDevice> by flowBlock(
        emptyMap(),
        REFRESH_MS,
    ) { context.connectionManager.bthDevices.toMap() }
    val known: Map<String, BthDevice> by flowBlock(
        emptyMap(),
        REFRESH_MS,
    ) { context.connectionManager.bthNetworks.toMap() }
    SettingsPageColumn {
        SettingsDeviceSection(BluetoothLabels.ADAPTERS, adapters.values)
        SettingsSection(title = BluetoothLabels.NEARBY) {
            if (known.isEmpty()) {
                SettingsInfoRow(label = BluetoothLabels.NONE, value = "")
            }
            known.values.forEach { device ->
                SettingsInfoRow(label = device.name, value = "")
            }
        }
    }
}

@Preview
@Composable
fun BluetoothSettingsPagePreview() = preview {
    BluetoothSettingsPage(context).Render()
}
