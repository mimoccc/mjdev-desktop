package org.mjdev.desktop.components.controlcenter.pages.about

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import org.mjdev.desktop.components.controlcenter.base.ControlCenterPage
import org.mjdev.desktop.components.controlcenter.settings.SettingsPageColumn
import org.mjdev.desktop.components.controlcenter.settings.SettingsSection
import org.mjdev.desktop.context.IDesktopContext
import org.mjdev.desktop.extensions.Compose.preview
import org.mjdev.desktop.components.controlcenter.settings.SettingsInfoRow
import org.mjdev.desktop.icons.custom.Mjdev

/** Static labels used by [AboutPage]. */
private object AboutLabels {
    const val SYSTEM = "System"
    const val MACHINE = "Machine"
    const val USER = "User"
    const val HOME = "Home"
    const val SHELL = "Shell"
    const val LOCALE = "Locale"
}

/** Control center page with basic information about this machine and the current user. */
@Suppress("FunctionName")
fun AboutPage(context: IDesktopContext) = ControlCenterPage(
    context = context,
    icon = Mjdev,
    name = "About",
    condition = { true },
) {
    SettingsPageColumn {
        SettingsSection(title = AboutLabels.SYSTEM) {
            SettingsInfoRow(AboutLabels.MACHINE, context.machineName)
            SettingsInfoRow(AboutLabels.LOCALE, context.currentLocale.toString())
        }
        SettingsSection(title = AboutLabels.USER) {
            SettingsInfoRow(AboutLabels.USER, currentUser.userName)
            SettingsInfoRow(AboutLabels.HOME, currentUser.home)
            SettingsInfoRow(AboutLabels.SHELL, currentUser.shell)
        }
    }
}

@Preview
@Composable
fun PreviewAboutPage() = preview {
    AboutPage(context).Render()
}
